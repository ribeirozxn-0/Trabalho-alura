function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let scene = 0;

function setup() {

  createCanvas(800, 600);

}

function draw() {

  background(30);

  if (scene === 0) {

    introScene();

  } else if (scene === 1) {

    choiceScene();

  } else if (scene === 2) {

    endingGood();

  } else if (scene === 3) {

    endingBad();

  }

}

// Cena de introdução

function introScene() {

  textAlign(CENTER, CENTER);

  textSize(28);

  fill(255);

  text("Bem-vindo ao Jogo de Escolhas!", width / 2, height / 2 - 50);

  textSize(18);

  text("Pressione qualquer tecla para começar sua jornada.", width / 2, height / 2 + 20);

}

// Cena com as escolhas

function choiceScene() {

  textAlign(CENTER, CENTER);

  textSize(22);

  fill(255);

  text("Você está diante de duas portas misteriosas.", width / 2, height / 3);

  text("Escolha com sabedoria:", width / 2, height / 3 + 40);

  // Botão 1

  fill(0, 150, 0);

  rect(width / 4 - 100, height / 2, 200, 50);

  fill(255);

  text("Porta Verde", width / 4, height / 2 + 25);

  // Botão 2

  fill(150, 0, 0);

  rect((3 * width) / 4 - 100, height / 2, 200, 50);

  fill(255);

  text("Porta Vermelha", (3 * width) / 4, height / 2 + 25);

}

// Final feliz

function endingGood() {

  background(0, 150, 0);

  textAlign(CENTER, CENTER);

  textSize(32);

  fill(255);

  text("Parabéns! Você encontrou o tesouro escondido!", width / 2, height / 2);

  textSize(18);

  text("Pressione R para jogar novamente.", width / 2, height / 2 + 50);

}

// Final ruim

function endingBad() {

  background(150, 0, 0);

  textAlign(CENTER, CENTER);

  textSize(32);

  fill(255);

  text("Que pena! Você foi capturado por monstros!", width / 2, height / 2);

  textSize(18);

  text("Pressione R para tentar novamente.", width / 2, height / 2 + 50);

}

// Interação com teclas

function keyPressed() {

  if (scene === 0) {

    scene = 1;

  } else if ((scene === 2 || scene === 3) && key === 'r') {

    scene = 0;

  }

}

// Interação com cliques

function mousePressed() {

  if (scene === 1) {

    // Porta Verde

    if (mouseX > width / 4 - 100 && mouseX < width / 4 + 100 && mouseY > height / 2 && mouseY < height / 2 + 50) {

      scene = 2;

    }

    // Porta Vermelha

    if (mouseX > (3 * width) / 4 - 100 && mouseX < (3 * width) / 4 + 100 && mouseY > height / 2 && mouseY < height / 2 + 50) {

      scene = 3;

    }

  }

}